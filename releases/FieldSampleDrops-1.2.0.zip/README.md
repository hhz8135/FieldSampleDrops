# 战地样本掉落 · 联机版（FieldSampleDrops 1.2.0）

适配 HellForge 0.4.0-beta、游戏构建 25480438、Bingus Shared Loader v20+ 和 HD2Runtime 0.50.1。

## 掉落规则

单人和多人任务均由当前任务的房主计算奖励。只统计归属于房主本人的敌人击杀，按潜兵与敌人死亡位置的三维直线距离判断。默认 30 米，正好达到上限也计数。每个敌人只计一次，房主增援后沿用本局进度。达到阈值时由房主在尸体处生成一个游戏原生样本。加入者不会再生成一份。

| 样本 | 默认击杀数 | 按难度启用范围 |
| --- | ---: | --- |
| 普通 | 20 | N1–N11 |
| 稀有 | 40 | N4–N11 |
| 超级 | 75 | N6–N11 |

三档独立累计，每局重置。可选读取 Treasure Map 1.4.0 的本局数据，不能确认的类型按难度判断。可整局不开战术地图。

## 安装和设置

在 HellForge 的 Mods 页导入 FieldSampleDrops-1.2.0.zip 并启用。此包使用独立 GUID、Lua 资源名和配置，可以与 MonsterSampleDrop 分别安装和启停。

安装 CowboyBingus Mod Options Menu 后，在 **Esc → MODS → 战地样本掉落 · 联机版** 调整三个击杀阈值和「击杀距离上限（米）」。距离为 1–300 米的整数。点「应用」后下一局生效。

未安装菜单时，编辑 HellForge 安装目录下的 `userdata/environment/Local/CowboyBingus/Helldivers2/FieldSampleDrops_CONFIG.ini`。独立配置使用以下默认值。

```ini
threshold_1 = 20
threshold_2 = 40
threshold_3 = 75
drop_radius_m = 30
show_ui = 1
```

如果与 MonsterSampleDrop 1.1.0 同时启用，单人时由旧版处理，队友加入后由本版处理。要在单人任务中也使用可调距离，可单独启用本版。如果检测到会直接发放样本的原版 v1.0，本版暂停掉落，避免同一次击杀领取两份奖励。

## 联机验证状态

房主提前向 HellForge 申请本局样本的资源包。HellForge 会通知同局玩家预载可共享的包，实际到达时间由客户端决定。样本使用游戏原生实体与拾取流程。队友可见、拾取、拾取后两端同时消失以及撤离只结算一次，尚待双人实机验证。 [HellForge 联机资源说明](https://github.com/SkyeShade/HellForge/blob/d8a8b46/docs/multiplayer.md#assets-in-co-op)

实测时，把普通样本阈值设为 1，由房主击杀，让队友先拾取。房主的 HD2Runtime.log 可搜索 `[FieldSampleDrops]`。其中 `network_id` 是房主在游戏网络对象表中查到的标识。`nil` 表示检查时未能解析，也可能是样本已经被取走。单侧标识无法确认队友已收到实体。

## 构建

解压源码，在含 build.ps1 的目录运行以下命令。安装包输出在 build/。

```powershell
.\build.ps1
```
